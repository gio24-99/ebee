package com.example.hotelproject.controller;

import com.example.hotelproject.dto.HotelDto;
import com.example.hotelproject.entity.Hotel;
import com.example.hotelproject.entity.Room;
import com.example.hotelproject.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hotel")
public class HotelController {
    private final HotelService hotelService;

    @Autowired
    public HotelController(HotelService hotelService) {
        this.hotelService = hotelService;
    }
    @GetMapping("{id}")
    public ResponseEntity<Hotel> getHotel(@PathVariable  Long id){
        return new ResponseEntity<>(hotelService.getHotel(id), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Hotel>> getAllHotel(){
        return new ResponseEntity<>(hotelService.getAllHotel(), HttpStatus.OK);
    }

    @GetMapping("name/{name}")
    public ResponseEntity<Hotel> getHotelByName(@PathVariable String name){
        return new ResponseEntity<>(hotelService.getHotelByName(name), HttpStatus.OK);
    }

    @GetMapping("available/{id}")
    public ResponseEntity<List<Room>> getAllAvailableRoom(@PathVariable  Long id){
        return new ResponseEntity<>(hotelService.getAllAvailableRoom(id), HttpStatus.OK);
    }
    @GetMapping("booked/{id}")
    public ResponseEntity<List<Room>> getAllBookedRoom(@PathVariable Long id){
        return new ResponseEntity<>(hotelService.getAllBookedRoom(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Hotel> addHotel(@RequestBody HotelDto hotelDto){
        return new ResponseEntity<>(hotelService.addHotel(hotelDto), HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<Hotel> updateHotel(@PathVariable Long id,@RequestParam(required = false) String name,@RequestParam(required = false) String address ){
        return new ResponseEntity<>(hotelService.updateHotel(id,name,address), HttpStatus.OK);
    }

    @PostMapping("add-room/{id}")
    public ResponseEntity<Hotel> addRoomToHotel(@PathVariable Long id,@RequestParam(required = false) Long roomId){
        return new ResponseEntity<>(hotelService.addRoomToHotel(id,roomId), HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Hotel> deleteHotel(@PathVariable Long id){
        return new ResponseEntity<>(hotelService.deleteHotel(id), HttpStatus.OK);
    }


}
