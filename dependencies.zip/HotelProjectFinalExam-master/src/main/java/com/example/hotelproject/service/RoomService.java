package com.example.hotelproject.service;


import com.example.hotelproject.dto.RoomDto;
import com.example.hotelproject.entity.Room;

import java.util.List;

public interface RoomService {

    Room getRoom(Long id);

    Room getRoomByNumber(Long number);

    List<Room> getAllAvailableRoom();
    List<Room> getAllBookedRoom();

    List<Room> getAllRoom();

    Room addRoom(RoomDto roomDto);

    Room updateRoom(Long id, Long number, Long price);

    Room deleteRoom(Long id);

}
