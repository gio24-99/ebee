package com.example.hotelproject.service;

import com.example.hotelproject.dto.HotelDto;
import com.example.hotelproject.entity.Booking;

import java.util.List;

public interface BookingService {
    Booking getBooking(Long id);

    List<Booking> getAllBooking();


    Booking addBooking(Long hotelId, Long roomId, String customerPersonalNo);

    Booking deleteBooking(Long id);
}
