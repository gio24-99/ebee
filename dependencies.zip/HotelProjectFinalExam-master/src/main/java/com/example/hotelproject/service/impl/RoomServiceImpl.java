package com.example.hotelproject.service.impl;

import com.example.hotelproject.dto.HotelDto;
import com.example.hotelproject.dto.RoomDto;
import com.example.hotelproject.entity.Hotel;
import com.example.hotelproject.entity.Room;
import com.example.hotelproject.exception.EntityNotFoundException;
import com.example.hotelproject.exception.InvalidPropertyException;
import com.example.hotelproject.record.RecordState;
import com.example.hotelproject.repository.RoomRepository;
import com.example.hotelproject.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;

    @Autowired
    public RoomServiceImpl(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    @Override
    public Room getRoom(Long id) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }

        return roomRepository.findById(id).orElseThrow( () -> new EntityNotFoundException("Room With This ID Not Found!"));
    }

    @Override
    public Room getRoomByNumber(Long number) {
        if (number == null){
            throw new InvalidPropertyException("ID Is Null");
        }

        return roomRepository.findByNumber(number).orElseThrow( () -> new EntityNotFoundException("Room With This Number Not Found!"));
    }

    @Override
    public List<Room> getAllAvailableRoom() {
        List<Room> availableRoomList = new ArrayList<>();
        for(Room room: roomRepository.findAll()){
            if (room.getRoomStatus() == Room.RoomStatus.AVAILABLE){
                availableRoomList.add(room);
            }
        }
        return availableRoomList;
    }

    @Override
    public List<Room> getAllBookedRoom() {
        List<Room> bookedRoomList = new ArrayList<>();
        for(Room room: roomRepository.findAll()){
            if (room.getRoomStatus() == Room.RoomStatus.BOOKED){
                bookedRoomList.add(room);
            }
        }
        return bookedRoomList;
    }

    @Override
    public List<Room> getAllRoom() {
        return roomRepository.findAll();
    }

    @Override
    public Room addRoom(RoomDto roomDto) {
        if(roomDto == null){
            throw new InvalidPropertyException("Room Object Is Null");
        }
        if(roomDto.getNumber() == null){
            throw new InvalidPropertyException("Room Number Is Null");
        }

        Room room = new Room(roomDto);
        return roomRepository.save(room);
    }

    @Override
    @Transactional
    public Room updateRoom(Long id, Long number, Long price) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }

        Optional<Room> room = roomRepository.findById(id);

        room.ifPresent(updateRoom ->{
            if(number != null && number > 0){
                updateRoom.setNumber(number);
            }
            if(price != null ){
                updateRoom.setPrice(price);
            }
        });

        return  room.orElseThrow( () -> new EntityNotFoundException("Room With This ID Not Found!"));
    }

    @Override
    public Room deleteRoom(Long id) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }

        Optional<Room> room = roomRepository.findById(id);
        room.ifPresent((deleteRoom) -> deleteRoom.setRecordState(RecordState.DELETED));

        return room.orElseThrow(() -> new EntityNotFoundException("Room With This ID Not Found!"));
    }
}
