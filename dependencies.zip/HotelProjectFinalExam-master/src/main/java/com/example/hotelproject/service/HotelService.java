package com.example.hotelproject.service;

import com.example.hotelproject.dto.HotelDto;
import com.example.hotelproject.entity.Hotel;
import com.example.hotelproject.entity.Room;

import java.util.List;

public interface HotelService {


    Hotel  getHotel(Long id);

    List<Room> getAllAvailableRoom(Long id) ;
    List<Room> getAllBookedRoom(Long id) ;

    Hotel addRoomToHotel(Long id, Long roomId);

    Hotel getHotelByName(String name);

    List<Hotel> getAllHotel();

    Hotel addHotel(HotelDto hotelDto);

    Hotel updateHotel(Long id, String name, String address);

    Hotel deleteHotel(Long id);



}
