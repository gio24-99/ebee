package com.example.hotelproject.exception;

import lombok.Getter;

@Getter
public class InvalidPropertyException extends RuntimeException{

    private String message;

    public InvalidPropertyException(String message) {
        super(message);
        this.message = message;
    }
}
