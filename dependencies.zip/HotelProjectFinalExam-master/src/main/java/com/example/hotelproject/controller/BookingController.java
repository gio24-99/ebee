package com.example.hotelproject.controller;

import com.example.hotelproject.dto.HotelDto;
import com.example.hotelproject.entity.Booking;
import com.example.hotelproject.entity.Hotel;
import com.example.hotelproject.service.BookingService;
import com.example.hotelproject.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/booking")
public class BookingController {
    private final BookingService bookingService;

    @Autowired
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }
    @GetMapping("{id}")
    public ResponseEntity<Booking> getBooking(@PathVariable Long id){
        return new ResponseEntity<>(bookingService.getBooking(id), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Booking>> getAllBooking(){
        return new ResponseEntity<>(bookingService.getAllBooking(), HttpStatus.OK);
    }



    @PostMapping
    public ResponseEntity<Booking> addBooking(@RequestParam Long hotelId, @RequestParam Long roomId, @RequestParam String customerPersonalNo){
        return new ResponseEntity<>(bookingService.addBooking(hotelId,roomId,customerPersonalNo), HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Booking> deleteBooking(@PathVariable Long id){
        return new ResponseEntity<>(bookingService.deleteBooking(id), HttpStatus.OK);
    }


}