package com.example.hotelproject.record;

public enum RecordState {
    ACTIVE,INACTIVE, DELETED
}
