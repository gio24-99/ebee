package com.example.hotelproject.controller;

import com.example.hotelproject.dto.HotelDto;
import com.example.hotelproject.dto.RoomDto;
import com.example.hotelproject.entity.Hotel;
import com.example.hotelproject.entity.Room;
import com.example.hotelproject.service.HotelService;
import com.example.hotelproject.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/room")
public class RoomController {
    private final RoomService roomService;

    @Autowired
    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    @GetMapping("{id}")
    public ResponseEntity<Room> getRoom(@PathVariable Long id){
        return new ResponseEntity<>(roomService.getRoom(id), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Room>> getAllRoom(){
        return new ResponseEntity<>(roomService.getAllRoom(), HttpStatus.OK);
    }

    @GetMapping("available")
    public ResponseEntity<List<Room>> getAllAvailableRoom(){
        return new ResponseEntity<>(roomService.getAllAvailableRoom(), HttpStatus.OK);
    }

    @GetMapping("booked")
    public ResponseEntity<List<Room>> getAllBookedRoom(){
        return new ResponseEntity<>(roomService.getAllBookedRoom(), HttpStatus.OK);
    }
    @GetMapping("number/{number}")
    public ResponseEntity<Room> getRoomByNumber(@PathVariable Long number){
        return new ResponseEntity<>(roomService.getRoomByNumber(number), HttpStatus.OK);
    }


    @PostMapping
    public ResponseEntity<Room> addRoom(@RequestBody RoomDto roomDto){
        return new ResponseEntity<>(roomService.addRoom(roomDto), HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<Room> updateRoom(@PathVariable Long id,@RequestParam(required = false) Long number,@RequestParam(required = false) Long price ){
        return new ResponseEntity<>(roomService.updateRoom(id,number,price), HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Room> deleteRoom(@PathVariable Long id){
        return new ResponseEntity<>(roomService.deleteRoom(id), HttpStatus.OK);
    }


}