package com.example.hotelproject.service.impl;

import com.example.hotelproject.dto.HotelDto;
import com.example.hotelproject.entity.Booking;
import com.example.hotelproject.entity.Hotel;
import com.example.hotelproject.entity.Room;
import com.example.hotelproject.exception.EntityNotFoundException;
import com.example.hotelproject.exception.InvalidPropertyException;
import com.example.hotelproject.record.RecordState;
import com.example.hotelproject.repository.BookingRepository;
import com.example.hotelproject.repository.HotelRepository;
import com.example.hotelproject.repository.RoomRepository;
import com.example.hotelproject.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImp implements BookingService {

    private final BookingRepository bookingRepository;
    private final RoomRepository roomRepository;
    private final HotelRepository hotelRepository;
    @Autowired
    public BookingServiceImp(BookingRepository bookingRepository, RoomRepository roomRepository, HotelRepository hotelRepository) {
        this.bookingRepository = bookingRepository;
        this.roomRepository = roomRepository;
        this.hotelRepository = hotelRepository;
    }



    @Override
    public Booking getBooking(Long id) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }

        return bookingRepository.findById(id).orElseThrow( () -> new EntityNotFoundException("Booking With This ID Not Found!"));
    }

    @Override
    public List<Booking> getAllBooking() {
        return bookingRepository.findAll();
    }

    @Override
    @Transactional
    public Booking addBooking(Long hotelId, Long roomId, String customerPersonalNo) {
        if(hotelRepository.existsById(hotelId) && roomRepository.existsById(roomId) ){
            Hotel hotel = hotelRepository.findById(hotelId).get();
            Room room = roomRepository.findById(roomId).get();

            if(hotel.getRoom().contains(room) && room.getRoomStatus() == Room.RoomStatus.AVAILABLE ) {
                Booking booking = new Booking(hotel, room, customerPersonalNo);
                room.setRoomStatus(Room.RoomStatus.BOOKED);
                return bookingRepository.save(booking);

            }

        }
        throw new EntityNotFoundException("Hotel Or Room Not Found! Or It's Already Booked!");

    }

    @Override
    public Booking deleteBooking(Long id) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }

        Optional<Booking> booking = bookingRepository.findById(id);
        booking.ifPresent((deleteBooking) -> deleteBooking.setRecordState(RecordState.DELETED));

        return booking.orElseThrow(() -> new EntityNotFoundException("Booking With This ID Not Found!"));
    }
}
