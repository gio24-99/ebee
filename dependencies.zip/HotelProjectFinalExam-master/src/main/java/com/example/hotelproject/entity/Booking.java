package com.example.hotelproject.entity;

import com.example.hotelproject.dto.HotelDto;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "Booking")
@Getter
@Setter
public class Booking extends AppEntity<Long> {
    @Id
    @SequenceGenerator(name = "Booking_Id_Seq" , sequenceName = "BOOKING_ID_SEQ",allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "BOOKING_ID_SEQ")
    private Long id;

    @OneToOne
    private Hotel hotel;

    @OneToOne
    private Room room;

    @Column(name = "customer_personalno",nullable = false)
    private String customerPersonalNo;

    public Booking(Hotel hotel, Room room, String customerPersonalNo) {
        this.hotel = hotel;
        this.room = room;
        this.customerPersonalNo = customerPersonalNo;
    }
}
