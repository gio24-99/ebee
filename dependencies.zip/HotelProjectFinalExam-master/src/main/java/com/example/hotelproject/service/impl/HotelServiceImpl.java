package com.example.hotelproject.service.impl;

import com.example.hotelproject.dto.HotelDto;
import com.example.hotelproject.entity.Hotel;
import com.example.hotelproject.entity.Room;
import com.example.hotelproject.exception.EntityNotFoundException;
import com.example.hotelproject.exception.InvalidPropertyException;
import com.example.hotelproject.record.RecordState;
import com.example.hotelproject.repository.HotelRepository;
import com.example.hotelproject.repository.RoomRepository;
import com.example.hotelproject.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class HotelServiceImpl implements HotelService {

    private final HotelRepository hotelRepository;
    private final RoomRepository roomRepository;

    @Autowired
    public HotelServiceImpl(HotelRepository hotelRepository, RoomRepository roomRepository) {
        this.hotelRepository = hotelRepository;
        this.roomRepository = roomRepository;
    }

    @Override
    public Hotel getHotel(Long id) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }

        return hotelRepository.findById(id).orElseThrow( () -> new EntityNotFoundException("Hotel With This ID Not Found!"));
    }

    @Override
    public List<Room> getAllAvailableRoom(Long id) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }
        List<Room> availableRoomList = new ArrayList<>();
        if(hotelRepository.existsById(id)){
            Hotel hotel = hotelRepository.findById(id).get();

            for( Room room : hotel.getRoom()){
                if(room.getRoomStatus() == Room.RoomStatus.AVAILABLE){
                    availableRoomList.add(room);
                }
            }

        }
        return availableRoomList;
    }

    @Override
    public List<Room> getAllBookedRoom(Long id) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }
        List<Room> bookedRoomList = new ArrayList<>();
        if(hotelRepository.existsById(id)){
            Hotel hotel = hotelRepository.findById(id).get();

            for( Room room : hotel.getRoom()){
                if(room.getRoomStatus() == Room.RoomStatus.BOOKED){
                    bookedRoomList.add(room);
                }
            }

        }
        return bookedRoomList;
    }

    @Override
    public Hotel getHotelByName(String name) {
        if (name == null){
            throw new InvalidPropertyException("ID Is Null");
        }

        return hotelRepository.findByName(name).orElseThrow( () -> new EntityNotFoundException("Hotel With This ID Not Found!"));
    }

    @Override
    public List<Hotel> getAllHotel() {
        return hotelRepository.findAll();
    }

    @Override
    public Hotel addHotel(HotelDto hotelDto) {
        if(hotelDto == null){
            throw new InvalidPropertyException("Hotel Object Is Null");
        }
        if(hotelDto.getName() == null){
            throw new InvalidPropertyException("Hotel Name Is Null");
        }

        Hotel hotel = new Hotel(hotelDto);
        return hotelRepository.save(hotel);
    }

    @Override
    @Transactional
    public Hotel updateHotel(Long id, String name, String address) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }

        Optional<Hotel> hotel = hotelRepository.findById(id);

        hotel.ifPresent(updateHotel ->{
            if(name != null && name.length() > 0){
                updateHotel.setName(name);
            }
            if(address != null && address.length() > 0){
                updateHotel.setAddress(address);
            }
        });

        return  hotel.orElseThrow( () -> new EntityNotFoundException("Hotel With This ID Not Found!"));
    }
    @Override
    @Transactional
    public Hotel addRoomToHotel(Long id, Long roomId){
        if (id == null && roomId == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0  && roomId <= 0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }
        Optional<Room> room = roomRepository.findById(roomId);
        Optional<Hotel> hotel = hotelRepository.findById(id);
        if(room.isPresent() && hotel.isPresent()){
            List<Room> roomList = hotel.get().getRoom();
            roomList.add(room.get());
            hotel.get().setRoom(roomList);
            return hotel.get();
        }
        else throw new EntityNotFoundException("Room Or Hotel Or Both Entity With This ID And Number Not Found!");
    }

    @Override
    public Hotel deleteHotel(Long id) {
        if (id == null){
            throw new InvalidPropertyException("ID Is Null");
        }
        if(id<=0){
            throw new InvalidPropertyException("Invalid ID Supplied");
        }

        Optional<Hotel> hotel = hotelRepository.findById(id);
        hotel.ifPresent((deleteHotel) -> deleteHotel.setRecordState(RecordState.DELETED));

        return hotel.orElseThrow(() -> new EntityNotFoundException("Hotel With This ID Not Found!"));
    }
}
