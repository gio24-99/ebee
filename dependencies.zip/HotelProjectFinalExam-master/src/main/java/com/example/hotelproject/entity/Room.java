package com.example.hotelproject.entity;

import com.example.hotelproject.dto.RoomDto;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Room")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Room extends AppEntity<Long> {

    @Id
    @SequenceGenerator(name = "Room_Id_Seq", sequenceName = "ROOM_ID_SEQ",allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ROOM_ID_SEQ")
    private Long id;

    @Column(name = "number", nullable = false)
    private Long number;

    @Column(name = "price" ,nullable = false)
    private Long price;

    @Column(name = "room_status")
    private RoomStatus roomStatus = RoomStatus.AVAILABLE;


    public Room(RoomDto roomDto) {
        this.number = roomDto.getNumber();
        this.price = roomDto.getPrice();
    }

    public enum RoomStatus{
        BOOKED, AVAILABLE
    }
}
