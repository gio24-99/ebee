package com.example.hotelproject.entity;

import com.example.hotelproject.dto.HotelDto;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "Hotel")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Hotel extends AppEntity<Long>{
    @Id
    @SequenceGenerator(name = "Hotel_Id_Seq" , sequenceName = "HOTEL_ID_SEQ",allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "HOTEL_ID_SEQ")
    private Long id;

    @Column(name = "name", nullable = false , unique = true)
    private String name;

    @Column(name = "address", nullable = false)
    private String address;

    @OneToMany
    private List<Room> room;
    public Hotel(HotelDto hotelDto) {
        this.name = hotelDto.getName();
        this.address = hotelDto.getAddress();
    }
}
